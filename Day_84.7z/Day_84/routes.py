from flask import render_template, redirect, url_for, request, flash, session
from app import app, db, login_manager
from models import User, Product, Order, OrderItem
from forms import RegisterForm
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required, current_user

# ---------------- LOGIN MANAGER ----------------
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ---------------- REGISTER ----------------
@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        hashed_password = generate_password_hash(form.password.data, method="pbkdf2:sha256")
        new_user = User(username=form.username.data,
                        email=form.email.data,
                        password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        flash("Account created! Please log in.", "success")
        return redirect(url_for("login"))
    return render_template("register.html", form=form)

# ---------------- LOGIN ----------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            flash("Login successful!", "success")
            return redirect(url_for("products"))
        flash("Invalid credentials!", "danger")
    return render_template("login.html")

# ---------------- LOGOUT ----------------
@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Logged out.", "info")
    return redirect(url_for("login"))

# ---------------- PRODUCTS ----------------
@app.route("/products", methods=["GET", "POST"])
@login_required
def products():
    if request.method == "POST" and current_user.is_admin:
        name = request.form["name"]
        price = request.form["price"]
        description = request.form["description"]
        new_product = Product(name=name, price=price, description=description)
        db.session.add(new_product)
        db.session.commit()
        flash("Product added!", "success")
    products = Product.query.all()
    return render_template("products.html", products=products)

@app.route("/delete_product/<int:product_id>")
@login_required
def delete_product(product_id):
    if current_user.is_admin:
        product = Product.query.get(product_id)
        if product:
            db.session.delete(product)
            db.session.commit()
            flash("Product deleted!", "info")
    return redirect(url_for("products"))

# ---------------- CART ----------------
@app.before_request
def init_cart():
    if "cart" not in session:
        session["cart"] = {}

@app.route("/add_to_cart/<int:product_id>")
@login_required
def add_to_cart(product_id):
    cart = session.get("cart", {})
    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    session["cart"] = cart
    flash("Added to cart!", "success")
    return redirect(url_for("products"))

@app.route("/cart")
@login_required
def cart():
    cart = session.get("cart", {})
    items, total = [], 0
    for product_id, qty in cart.items():
        product = Product.query.get(int(product_id))
        if product:
            subtotal = product.price * qty
            items.append({"product": product, "qty": qty, "subtotal": subtotal})
            total += subtotal
    return render_template("cart.html", items=items, total=total)

@app.route("/remove_from_cart/<int:product_id>")
@login_required
def remove_from_cart(product_id):
    cart = session.get("cart", {})
    cart.pop(str(product_id), None)
    session["cart"] = cart
    flash("Item removed.", "info")
    return redirect(url_for("cart"))

@app.route("/clear_cart")
@login_required
def clear_cart():
    session["cart"] = {}
    flash("Cart cleared.", "warning")
    return redirect(url_for("cart"))

# ---------------- CHECKOUT ----------------
@app.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    cart = session.get("cart", {})
    if not cart:
        flash("Cart is empty!", "warning")
        return redirect(url_for("products"))

    items, total = [], 0
    for product_id, qty in cart.items():
        product = Product.query.get(int(product_id))
        if product:
            subtotal = product.price * qty
            items.append({"product": product, "qty": qty, "subtotal": subtotal})
            total += subtotal

    if request.method == "POST":
        new_order = Order(user_id=current_user.id, total=total)
        db.session.add(new_order)
        db.session.commit()

        for item in items:
            order_item = OrderItem(order_id=new_order.id,
                                   product_id=item["product"].id,
                                   quantity=item["qty"],
                                   price=item["product"].price)
            db.session.add(order_item)
        db.session.commit()

        session["cart"] = {}
        flash("Order placed!", "success")
        return redirect(url_for("orders"))

    return render_template("checkout.html", items=items, total=total)

# ---------------- ORDERS ----------------
@app.route("/orders")
@login_required
def orders():
    if current_user.is_admin:
        all_orders = Order.query.all()
    else:
        all_orders = Order.query.filter_by(user_id=current_user.id).all()
    return render_template("orders.html", orders=all_orders)
